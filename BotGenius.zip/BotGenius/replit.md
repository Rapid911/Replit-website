# Project Zero - AI Chatbot Solutions

## Overview

Project Zero is a full-stack web application focused on AI chatbot solutions. The application serves as a platform for showcasing AI-powered conversational experiences and includes a contact management system. It features a modern React frontend with a Node.js/Express backend, using PostgreSQL for data persistence. The website is publicly accessible without authentication requirements.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React with TypeScript**: Modern component-based UI using functional components and hooks
- **Vite Build System**: Fast development server and optimized production builds
- **Wouter Router**: Lightweight client-side routing for single-page application navigation
- **TanStack Query**: Server state management with caching and background updates
- **Shadcn/UI Components**: Comprehensive UI component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first styling with custom design system variables
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

### Backend Architecture
- **Express.js Server**: RESTful API with middleware for logging, JSON parsing, and error handling
- **TypeScript**: End-to-end type safety across server and shared code
- **Drizzle ORM**: Type-safe database operations with PostgreSQL
- **Session-based Authentication**: Express sessions with PostgreSQL storage
- **Modular Route Structure**: Organized API endpoints with proper error handling

### Data Storage
- **PostgreSQL Database**: Primary data store with Neon serverless hosting
- **Drizzle Schema**: Type-safe database schema definitions
- **Session Storage**: PostgreSQL-backed session management for authentication
- **Migration System**: Database schema versioning with Drizzle Kit

### Public Access
- **No Authentication Required**: Website is publicly accessible to all visitors
- **Contact Form**: Simple contact form for user inquiries and business communications
- **Direct Navigation**: Users can freely navigate between all pages without login

### UI/UX Design Patterns
- **Dark Theme**: Custom color scheme with gold accent colors for professional appearance
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts
- **Background Slideshow**: Dynamic image rotation for visual appeal
- **Navigation System**: Collapsible sidebar with gear icon trigger
- **Toast Notifications**: User feedback system for actions and errors

## External Dependencies

### Database & Hosting
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Replit Platform**: Development and deployment environment

### UI Component Libraries
- **Radix UI**: Headless component primitives for accessibility
- **Lucide React**: Icon library for consistent iconography
- **Shadcn/UI**: Pre-built component system with Tailwind integration

### Development Tools
- **Vite**: Development server with hot module replacement
- **ESBuild**: Fast JavaScript/TypeScript bundler for production
- **TypeScript**: Static type checking and enhanced developer experience
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens

### External APIs & Services
- **Unsplash Images**: Stock photography for background slideshow and project showcases
- **Font Awesome**: Icon fonts for UI elements
- **Google Fonts**: Web typography (Inter font family)

### Form & Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Runtime type validation for form inputs and API data
- **Hookform Resolvers**: Integration layer between React Hook Form and Zod

### State Management
- **TanStack Query**: Server state management with intelligent caching
- **React Context**: Local state management for UI state and navigation

## Recent Changes

### December 2024: Authentication Removal & Project Completion
- **Removed Authentication System**: Eliminated Replit Auth integration to make website publicly accessible
- **Simplified Architecture**: Removed user management, sessions, and protected routes
- **Direct Access**: All pages (Home, About, Contact) now accessible without login
- **Contact Form Only**: Retained contact form functionality for business inquiries
- **Database Cleanup**: Removed user and session tables, kept only contacts table
- **Final Website State**: Complete responsive website with black/gold theme, animated navigation, background slideshow, portfolio showcase, and working contact form
- **Code Organization**: All frontend components properly structured, backend simplified to essential contact API, styling complete with custom theme variables