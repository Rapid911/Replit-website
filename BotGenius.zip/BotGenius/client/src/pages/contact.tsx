import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Navigation from "@/components/navigation";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const contactSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  subject: z.string().min(1, "Please select a subject"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type ContactFormData = z.infer<typeof contactSchema>;

export default function Contact() {
  const { toast } = useToast();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Your message has been sent successfully. We'll get back to you soon!",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate(data);
  };



  return (
    <div className="min-h-screen bg-pattern relative">
      <Navigation />
      
      <div className="py-20 px-6 lg:px-20">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl lg:text-6xl font-bold text-gold mb-12 text-center">Get In Touch</h2>
          <p className="text-xl text-gold text-opacity-90 text-center mb-16">
            Ready to transform your business with AI chatbot technology? Let's discuss your project.
          </p>
          
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-black bg-opacity-70 p-8 rounded-xl border border-gold border-opacity-30">
              <h3 className="text-2xl font-semibold text-gold mb-6">Send us a message</h3>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gold">Full Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your full name"
                            className="bg-black bg-opacity-50 border-gold border-opacity-30 text-gold placeholder-gold placeholder-opacity-50 focus:border-gold focus:ring-gold focus:ring-opacity-20"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gold">Email Address</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="Enter your email address"
                            className="bg-black bg-opacity-50 border-gold border-opacity-30 text-gold placeholder-gold placeholder-opacity-50 focus:border-gold focus:ring-gold focus:ring-opacity-20"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gold">Subject</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-black bg-opacity-50 border-gold border-opacity-30 text-gold focus:border-gold focus:ring-gold focus:ring-opacity-20">
                              <SelectValue placeholder="Select a subject" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-black border-gold text-gold">
                            <SelectItem value="consultation">Free Consultation</SelectItem>
                            <SelectItem value="project">New Project</SelectItem>
                            <SelectItem value="support">Technical Support</SelectItem>
                            <SelectItem value="partnership">Partnership</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gold">Message</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Enter your message"
                            rows={4}
                            className="bg-black bg-opacity-50 border-gold border-opacity-30 text-gold placeholder-gold placeholder-opacity-50 focus:border-gold focus:ring-gold focus:ring-opacity-20 resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit"
                    disabled={contactMutation.isPending}
                    className="w-full bg-gradient-to-r from-gold to-dark-gold text-black font-semibold 
                               py-3 px-6 rounded-lg hover:from-light-gold hover:to-gold transform 
                               hover:scale-105 transition-all duration-300 shadow-lg disabled:opacity-50"
                  >
                    {contactMutation.isPending ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </Form>
            </div>
            
            {/* Contact Information */}
            <div className="space-y-8">
              <div className="bg-black bg-opacity-70 p-6 rounded-xl border border-gold border-opacity-30">
                <div className="flex items-center space-x-4 mb-4">
                  <i className="fas fa-map-marker-alt text-2xl text-gold"></i>
                  <h4 className="text-xl font-semibold text-gold">Our Location</h4>
                </div>
                <p className="text-gold text-opacity-80">
                  Silicon Valley Tech Hub<br />
                  123 Innovation Drive<br />
                  Nairobi, CA 94105
                </p>
              </div>
              
              <div className="bg-black bg-opacity-70 p-6 rounded-xl border border-gold border-opacity-30">
                <div className="flex items-center space-x-4 mb-4">
                  <i className="fas fa-phone text-2xl text-gold"></i>
                  <h4 className="text-xl font-semibold text-gold">Phone</h4>
                </div>
                <p className="text-gold text-opacity-80">
                  +254 731 892 154<br />
                  +254 725 816 280
                </p>
              </div>
              
              <div className="bg-black bg-opacity-70 p-6 rounded-xl border border-gold border-opacity-30">
                <div className="flex items-center space-x-4 mb-4">
                  <i className="fas fa-envelope text-2xl text-gold"></i>
                  <h4 className="text-xl font-semibold text-gold">Email</h4>
                </div>
                <p className="text-gold text-opacity-80">
                  info@projectzero.ai<br />
                  support@projectzero.ai
                </p>
              </div>
              
              <div className="bg-black bg-opacity-70 p-6 rounded-xl border border-gold border-opacity-30">
                <div className="flex items-center space-x-4 mb-4">
                  <i className="fas fa-clock text-2xl text-gold"></i>
                  <h4 className="text-xl font-semibold text-gold">Business Hours</h4>
                </div>
                <p className="text-gold text-opacity-80">
                  Monday - Friday: 9:00 AM - 6:00 PM<br />
                  Saturday: 10:00 AM - 4:00 PM<br />
                  Sunday: Closed
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
