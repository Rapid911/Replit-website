import Navigation from "@/components/navigation";
import BackgroundSlideshow from "@/components/background-slideshow";

export default function Home() {

  return (
    <div className="min-h-screen relative">
      <Navigation />
      
      {/* Background Slideshow */}
      <BackgroundSlideshow />
      
      <div className="absolute inset-0 bg-black bg-opacity-60"></div>
      
      <div className="relative z-10 flex items-center min-h-screen px-6 lg:px-20">
        <div className="max-w-4xl">
          <h1 className="text-5xl lg:text-7xl font-bold text-gold mb-6 animate-fade-in">
            Welcome to <span className="text-light-gold">Project Zero</span>
          </h1>
          <p className="text-xl lg:text-2xl text-gold text-opacity-90 mb-8 leading-relaxed animate-fade-in">
            Revolutionizing communication through cutting-edge AI chatbot technology. 
            We create intelligent conversational experiences that bridge the gap between 
            human interaction and artificial intelligence.
          </p>
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <div className="bg-black bg-opacity-70 p-6 rounded-xl border border-gold border-opacity-30">
              <i className="fas fa-robot text-3xl text-gold mb-4"></i>
              <h3 className="text-xl font-semibold text-gold mb-2">AI-Powered</h3>
              <p className="text-gold text-opacity-80">Advanced machine learning algorithms power our chatbots</p>
            </div>
            <div className="bg-black bg-opacity-70 p-6 rounded-xl border border-gold border-opacity-30">
              <i className="fas fa-lightning-bolt text-3xl text-gold mb-4"></i>
              <h3 className="text-xl font-semibold text-gold mb-2">Lightning Fast</h3>
              <p className="text-gold text-opacity-80">Instant responses with sub-second processing times</p>
            </div>
            <div className="bg-black bg-opacity-70 p-6 rounded-xl border border-gold border-opacity-30">
              <i className="fas fa-shield-alt text-3xl text-gold mb-4"></i>
              <h3 className="text-xl font-semibold text-gold mb-2">Secure</h3>
              <p className="text-gold text-opacity-80">Enterprise-grade security for all communications</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
