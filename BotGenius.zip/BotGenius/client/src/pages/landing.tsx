import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = () => {
    setIsLoading(true);
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-pattern relative overflow-hidden">
      {/* Background Images */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="AI technology background" 
          className="w-full h-full object-cover opacity-30"
        />
      </div>
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-black bg-opacity-70 z-10"></div>
      
      {/* Login Form */}
      <div className="relative z-20 max-w-md w-full mx-4">
        <Card className="bg-black bg-opacity-90 backdrop-blur-sm border border-gold border-opacity-30 rounded-2xl shadow-2xl">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gold mb-2">Project Zero</h1>
              <p className="text-gold text-opacity-80">AI Chatbot Solutions</p>
            </div>
            
            <div className="space-y-6">
              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-gold mb-2">
                  Email Address
                </Label>
                <Input 
                  type="email" 
                  id="email" 
                  name="email" 
                  required
                  className="w-full px-4 py-3 bg-black bg-opacity-50 border border-gold border-opacity-30 rounded-lg 
                             text-gold placeholder-gold placeholder-opacity-50 focus:outline-none focus:border-gold 
                             focus:ring-2 focus:ring-gold focus:ring-opacity-20 transition-all duration-300"
                  placeholder="Enter your email"
                />
              </div>
              
              <div>
                <Label htmlFor="password" className="block text-sm font-medium text-gold mb-2">
                  Password
                </Label>
                <Input 
                  type="password" 
                  id="password" 
                  name="password" 
                  required
                  className="w-full px-4 py-3 bg-black bg-opacity-50 border border-gold border-opacity-30 rounded-lg 
                             text-gold placeholder-gold placeholder-opacity-50 focus:outline-none focus:border-gold 
                             focus:ring-2 focus:ring-gold focus:ring-opacity-20 transition-all duration-300"
                  placeholder="Enter your password"
                />
              </div>
              
              <Button 
                onClick={handleLogin}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-gold to-dark-gold text-black font-semibold py-3 px-6 
                           rounded-lg hover:from-light-gold hover:to-gold transform hover:scale-105 
                           transition-all duration-300 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? "Authenticating..." : "Enter Dashboard"}
              </Button>
            </div>
            
            <div className="mt-6 text-center">
              <p className="text-gold text-opacity-60 text-sm">
                Secure access to AI chatbot management platform
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
