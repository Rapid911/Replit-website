import Navigation from "@/components/navigation";

const projects = [
  {
    title: "E-Commerce Assistant",
    description: "AI-powered shopping assistant that increased customer satisfaction by 85% and reduced support tickets by 60%.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    tags: ["NLP", "ML", "API Integration"]
  },
  {
    title: "HealthCare Advisor",
    description: "Medical consultation chatbot that provides preliminary health assessments and appointment scheduling for 500+ clinics.",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    tags: ["Medical AI", "HIPAA Compliant", "Scheduling"]
  },
  {
    title: "FinTech Assistant",
    description: "Intelligent financial advisor that helps users manage investments, track expenses, and plan budgets with personalized recommendations.",
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    tags: ["Financial AI", "Security", "Analytics"]
  },
  {
    title: "EduBot Tutor",
    description: "Personalized learning assistant that adapts to student pace and provides interactive educational content across multiple subjects.",
    image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    tags: ["Adaptive Learning", "Multi-language", "Progress Tracking"]
  },
  {
    title: "Support Genius",
    description: "24/7 customer support chatbot that resolves 90% of common queries instantly while seamlessly escalating complex issues to human agents.",
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    tags: ["24/7 Support", "Escalation", "Multilingual"]
  },
  {
    title: "PropertyFinder AI",
    description: "Intelligent real estate assistant that matches buyers with perfect properties using advanced preference learning and market analysis.",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    tags: ["Property Matching", "Market Analysis", "Virtual Tours"]
  }
];

export default function About() {

  return (
    <div className="min-h-screen bg-pattern relative">
      <Navigation />
      
      <div className="py-20 px-6 lg:px-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl lg:text-6xl font-bold text-gold mb-12 text-center">Our Portfolio</h2>
          <p className="text-xl text-gold text-opacity-90 text-center mb-16 max-w-3xl mx-auto">
            Discover the innovative AI chatbot solutions we've delivered across various industries, 
            transforming customer experiences and business operations.
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="bg-black bg-opacity-70 rounded-xl overflow-hidden border border-gold border-opacity-30 
                          hover:border-opacity-60 transition-all duration-300 transform hover:scale-105">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gold mb-3">{project.title}</h3>
                  <p className="text-gold text-opacity-80 mb-4">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span key={tagIndex} className="px-3 py-1 bg-gold bg-opacity-20 text-gold text-sm rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
