import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [location] = useLocation();

  const toggleNav = () => {
    setIsNavOpen(!isNavOpen);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <>
      {/* Gear Icon for Navigation */}
      <button
        onClick={toggleNav}
        className="fixed top-6 left-6 z-50 w-12 h-12 bg-gold text-black rounded-full 
                   shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-300 
                   flex items-center justify-center"
      >
        <i className={cn(
          "fas fa-cog text-xl transition-transform duration-300 ease-in-out",
          isNavOpen && "rotate-360"
        )}></i>
      </button>

      {/* Vertical Navigation */}
      <nav className={cn(
        "fixed top-0 left-0 h-full w-64 bg-black bg-opacity-95 backdrop-blur-sm",
        "border-r border-gold border-opacity-30 z-40 transform transition-transform",
        "duration-300 ease-in-out",
        isNavOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6 pt-20">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gold">Project Zero</h2>
            <p className="text-gold text-opacity-70 text-sm">AI Solutions</p>
          </div>
          
          <ul className="space-y-4">
            <li>
              <Link href="/" onClick={() => setIsNavOpen(false)}>
                <div className={cn(
                  "flex items-center space-x-3 text-gold hover:text-light-gold",
                  "transition-colors duration-300 py-3 px-4 rounded-lg hover:bg-gold hover:bg-opacity-10",
                  location === "/" && "bg-gold bg-opacity-20 text-light-gold"
                )}>
                  <i className="fas fa-home"></i>
                  <span>Home</span>
                </div>
              </Link>
            </li>
            <li>
              <Link href="/about" onClick={() => setIsNavOpen(false)}>
                <div className={cn(
                  "flex items-center space-x-3 text-gold hover:text-light-gold",
                  "transition-colors duration-300 py-3 px-4 rounded-lg hover:bg-gold hover:bg-opacity-10",
                  location === "/about" && "bg-gold bg-opacity-20 text-light-gold"
                )}>
                  <i className="fas fa-info-circle"></i>
                  <span>About</span>
                </div>
              </Link>
            </li>
            <li>
              <Link href="/contact" onClick={() => setIsNavOpen(false)}>
                <div className={cn(
                  "flex items-center space-x-3 text-gold hover:text-light-gold",
                  "transition-colors duration-300 py-3 px-4 rounded-lg hover:bg-gold hover:bg-opacity-10",
                  location === "/contact" && "bg-gold bg-opacity-20 text-light-gold"
                )}>
                  <i className="fas fa-envelope"></i>
                  <span>Contact</span>
                </div>
              </Link>
            </li>
          </ul>
          

        </div>
      </nav>

      {/* Overlay */}
      {isNavOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setIsNavOpen(false)}
        />
      )}
    </>
  );
}
