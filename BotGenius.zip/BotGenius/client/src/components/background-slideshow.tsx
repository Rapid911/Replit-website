import { useState, useEffect } from "react";

const images = [
  "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
  "https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
  "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
  "https://images.unsplash.com/photo-1555949963-aa79dcee981c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
  "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
  "https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
];

const imageDescriptions = [
  "Futuristic AI technology lab with blue holographic displays",
  "Software development team collaborating in modern office",
  "Modern chatbot interface on multiple screens",
  "AI neural network visualization",
  "Modern office workspace with AI technology",
  "AI chatbot conversation interface"
];

export default function BackgroundSlideshow() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % images.length);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden">
      <div className="slideshow-container relative w-full h-full">
        {images.map((image, index) => (
          <img
            key={index}
            src={image}
            alt={imageDescriptions[index]}
            className={`absolute inset-0 w-full h-full object-cover opacity-40 transition-opacity duration-1000 ${
              index === currentSlide ? "opacity-40" : "opacity-0"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
