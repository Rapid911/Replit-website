import {
  contacts,
  type InsertContact,
  type Contact,
} from "@shared/schema";
import { db } from "./db";

// Interface for storage operations
export interface IStorage {
  // Contact operations
  createContact(contact: InsertContact): Promise<Contact>;
}

export class DatabaseStorage implements IStorage {
  // Contact operations
  async createContact(contactData: InsertContact): Promise<Contact> {
    const [contact] = await db
      .insert(contacts)
      .values(contactData)
      .returning();
    return contact;
  }
}

export const storage = new DatabaseStorage();
